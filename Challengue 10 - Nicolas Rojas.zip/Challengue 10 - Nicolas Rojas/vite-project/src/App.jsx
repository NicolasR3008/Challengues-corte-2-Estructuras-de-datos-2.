// Nicolas Rojas - 2226088
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { increment, decrement, incrementBy } from './store/slices/counterSlice';
import { push, pop, clear } from './store/slices/stackSlice';

const App = () => {
  const dispatch = useDispatch();
  const { count } = useSelector((state) => state.counter);
  const { items } = useSelector((state) => state.stack);
  const [inputValue, setInputValue] = useState('');
  const [stackInput, setStackInput] = useState('');

  const handleIncrementBy = (e) => {
    e.preventDefault();
    const value = parseInt(inputValue);
    if (!isNaN(value)) {
      dispatch(incrementBy(value));
      setInputValue('');
    }
  };

  const handlePush = (e) => {
    e.preventDefault();
    const value = parseInt(stackInput);
    if (!isNaN(value)) {
      dispatch(push(value));
      setStackInput('');
    }
  };

  return (
    <div className="container">
      <header>
        <h1>Redux Challenge 10</h1>
      </header>

      <section className="counter-section">
        <h2>Counter: {count}</h2>
        
        <div className="button-group">
          <button 
            className="btn primary"
            onClick={() => dispatch(increment())}
          >
            Increment
          </button>
          <button 
            className="btn danger"
            onClick={() => dispatch(decrement())}
          >
            Decrement
          </button>
        </div>

        <form onSubmit={handleIncrementBy}>
          <input
            type="number"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Enter increment value"
          />
          <button 
            className="btn secondary"
            type="submit"
          >
            Increment By
          </button>
        </form>
      </section>

      <section className="stack-section">
        <h2>Stack Operations</h2>
        
        <form onSubmit={handlePush}>
          <input
            type="number"
            value={stackInput}
            onChange={(e) => setStackInput(e.target.value)}
            placeholder="Enter stack value"
          />
          <button 
            className="btn primary"
            type="submit"
          >
            Push
          </button>
        </form>

        <div className="button-group">
          <button 
            className="btn warning"
            onClick={() => dispatch(pop())}
          >
            Pop
          </button>
          <button 
            className="btn danger"
            onClick={() => dispatch(clear())}
          >
            Clear Stack
          </button>
        </div>

        <div className="stack-display">
          <h3>Current Stack:</h3>
          {items.length === 0 ? (
            <p>Stack is empty</p>
          ) : (
            <ul>
              {items.map((item, index) => (
                <li key={index}>
                  {item} {index === items.length - 1 && '(Top)'}
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
};

export default App;