//Nicolas Rojas Cabal - 2226088

import { useState } from 'react';
import Pila from './Pila';

export const Libros = () => {
  const [pilaLibros] = useState(new Pila());
  const [nuevoLibro, setNuevoLibro] = useState({
    nombre: '',
    isbn: '',
    autor: '',
    editorial: ''
  });
  const [mostrarLibros, setMostrarLibros] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNuevoLibro(prev => ({ ...prev, [name]: value }));
  };

  const agregarLibro = (e) => {
    e.preventDefault();
    pilaLibros.apilar(nuevoLibro);
    setMostrarLibros(pilaLibros.verTodos());
    setNuevoLibro({
      nombre: '',
      isbn: '',
      autor: '',
      editorial: ''
    });
  };

  const quitarLibro = () => {
    pilaLibros.desapilar();
    setMostrarLibros(pilaLibros.verTodos());
  };

  return (
    <div className="libros-container">
      <h2>Pila de Libros</h2>
      
      <form onSubmit={agregarLibro} className="libros-form">
        <input
          name="nombre"
          placeholder="Nombre del libro"
          value={nuevoLibro.nombre}
          onChange={handleChange}
          required
        />
        <input
          name="isbn"
          placeholder="ISBN"
          value={nuevoLibro.isbn}
          onChange={handleChange}
          required
        />
        <input
          name="autor"
          placeholder="Autor"
          value={nuevoLibro.autor}
          onChange={handleChange}
          required
        />
        <input
          name="editorial"
          placeholder="Editorial"
          value={nuevoLibro.editorial}
          onChange={handleChange}
          required
        />
        <button type="submit">Agregar Libro</button>
      </form>

      <button onClick={quitarLibro} className="quitar-btn">
        Quitar Último Libro
      </button>

      <div className="libros-list">
        <h3>Libros en la pila ({pilaLibros.tamaño()}):</h3>
        {mostrarLibros.map((libro, index) => (
          <div key={index} className="libro-card">
            <p><strong>Nombre:</strong> {libro.nombre}</p>
            <p><strong>ISBN:</strong> {libro.isbn}</p>
            <p><strong>Autor:</strong> {libro.autor}</p>
            <p><strong>Editorial:</strong> {libro.editorial}</p>
          </div>
        ))}
      </div>
    </div>
  );
};