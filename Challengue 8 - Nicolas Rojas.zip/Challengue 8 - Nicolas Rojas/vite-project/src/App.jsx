//Nicolas Rojas Cabal - 2226088

import { Libros } from './Libros';
import './styles.css';

function App() {
  return (
    <div className="app">
      <h1>Challenge 08 - Pila de Libros</h1>
      <Libros />
    </div>
  );
}

export default App;