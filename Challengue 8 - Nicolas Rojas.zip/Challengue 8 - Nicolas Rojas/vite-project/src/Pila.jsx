//Nicolas Rojas Cabal - 2226088


export default class Pila {
    constructor() {
      this.libros = [];
    }
  
    apilar(libro) {
      this.libros.push(libro);
    }
  
    desapilar() {
      return this.libros.pop();
    }
  
    verTodos() {
      return [...this.libros].reverse(); // Mostrar del más reciente al más antiguo
    }
  
    tamaño() {
      return this.libros.length;
    }
  }