//Nicolas Rojas - 2226088

import { useState } from 'react';
import Cola from './Cola';

export const ATM = () => {
  const [colaATM] = useState(new Cola());
  const [nuevaPersona, setNuevaPersona] = useState({
    nombre: '',
    monto: ''
  });
  const [mostrarPersonas, setMostrarPersonas] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNuevaPersona(prev => ({ ...prev, [name]: value }));
  };

  const agregarPersona = (e) => {
    e.preventDefault();
    colaATM.encolar({
      nombre: nuevaPersona.nombre,
      monto: parseFloat(nuevaPersona.monto)
    });
    setMostrarPersonas(colaATM.verTodos());
    setNuevaPersona({ nombre: '', monto: '' });
  };

  const atenderPersona = () => {
    const personaAtendida = colaATM.desencolar();
    if (personaAtendida) {
      alert(`Atendiendo a: ${personaAtendida.nombre}\nMonto: $${personaAtendida.monto}`);
      setMostrarPersonas(colaATM.verTodos());
    }
  };

  return (
    <div className="atm-container">
      <h2>Cola del Cajero Automático</h2>
      
      <form onSubmit={agregarPersona} className="atm-form">
        <input
          name="nombre"
          placeholder="Nombre"
          value={nuevaPersona.nombre}
          onChange={handleChange}
          required
        />
        <input
          name="monto"
          type="number"
          placeholder="Monto a retirar"
          value={nuevaPersona.monto}
          onChange={handleChange}
          min="1"
          required
        />
        <button type="submit">Agregar a la cola</button>
      </form>

      <button onClick={atenderPersona} className="atender-btn">
        Atender Siguiente
      </button>

      <div className="cola-list">
        <h3>Personas en cola ({colaATM.tamaño()}):</h3>
        {mostrarPersonas.length > 0 ? (
          <ul>
            {mostrarPersonas.map((persona, index) => (
              <li key={index} className="persona-card">
                <p><strong>Nombre:</strong> {persona.nombre}</p>
                <p><strong>Monto a retirar:</strong> ${persona.monto}</p>
                {index === 0 && <span className="siguiente">(Siguiente)</span>}
              </li>
            ))}
          </ul>
        ) : (
          <p>No hay personas en cola</p>
        )}
      </div>
    </div>
  );
};