//Nicolas Rojas - 2226088
export default class Cola {
    constructor() {
      this.personas = [];
    }
  
    encolar(persona) {
      this.personas.push(persona);
    }
  
    desencolar() {
      return this.personas.shift();
    }
  
    verTodos() {
      return [...this.personas]; // Mostrar en orden FIFO
    }
  
    tamaño() {
      return this.personas.length;
    }
  }