//Nicolas Rojas - 2226088

import { ATM } from './ATM';
import './styles.css';

function App() {
  return (
    <div className="app">
      <h1>Challenge 09 - Cola de ATM</h1>
      <ATM />
    </div>
  );
}

export default App;