//Nicolas Rojas- 2226088

import { useState } from 'react';

class PageNode {
  constructor(url) {
    this.url = url;
    this.next = null;
    this.prev = null;
  }
}

class NavHistory {
  constructor() {
    this.current = null;
  }

  add(url) {
    const node = new PageNode(url);
    if (!this.current) {
      this.current = node;
    } else {
      node.prev = this.current;
      this.current.next = node;
      this.current = node;
    }
  }
}

const pages = [
  "https://www.pokemon.com/el",
  "https://www.friv.com/z/play/juegos.html",
  "https://www.higherlowergame.com"
];

export default function Browser() {
  const [history] = useState(() => {
    const h = new NavHistory();
    pages.forEach(page => h.add(page));
    return h;
  });
  const [currentPage, setCurrentPage] = useState(history.current?.url || pages[0]);

  const goBack = () => {
    const prev = history.back();
    if (prev) setCurrentPage(prev);
  };

  const goForward = () => {
    const next = history.forward();
    if (next) setCurrentPage(next);
  };

  return (
    <div className="screen">
      <h1>Navegador de Juegos</h1>
      <div className="nav-buttons">
        <button onClick={goBack} disabled={!history.current?.prev}>
          Atrás
        </button>
        <button onClick={goForward} disabled={!history.current?.next}>
          Adelante
        </button>
      </div>
      <iframe 
        src={currentPage} 
        title="Juegos" 
        className="page-view"
        sandbox="allow-same-origin allow-scripts allow-popups"
      />
    </div>
  );
}