//Nicolas Rojas- 2226088
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Player from './Player';
import Browser from './Browser';
import './styles.css';

export default function App() {
  return (
    <BrowserRouter>
      <div className="navbar">
        <Link to="/player">Player</Link>
        <Link to="/browser">Browser</Link>
      </div>

      <Routes>
        <Route path="/player" element={<Player />} />
        <Route path="/browser" element={<Browser />} />
      </Routes>
    </BrowserRouter>
  );
}