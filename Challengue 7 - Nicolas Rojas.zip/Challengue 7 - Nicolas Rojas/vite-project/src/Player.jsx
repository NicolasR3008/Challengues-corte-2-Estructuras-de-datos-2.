//Nicolas Rojas- 2226088

import { useState } from 'react';

class MusicNode {
  constructor(song) {
    this.song = song;
    this.next = null;
  }
}

class SongList {
  constructor() {
    this.head = null;
    this.current = null;
  }

  add(song) {
    const node = new MusicNode(song);
    if (!this.head) {
      this.head = node;
      this.current = node;
    } else {
      let last = this.head;
      while (last.next) last = last.next;
      last.next = node;
    }
  }

  next() {
    if (this.current?.next) {
      this.current = this.current.next;
      return this.current.song;
    }
    return null;
  }
}

const songs = [
  { name: "Bohemian Rhapsody", artist: "Queen" },
  { name: "Imagine", artist: "John Lennon" },
  { name: "Yesterday", artist: "The Beatles" }
];

export default function Player() {
  const [list] = useState(() => {
    const l = new SongList();
    songs.forEach(song => l.add(song));
    return l;
  });
  const [current, setCurrent] = useState(list.current?.song || songs[0]);

  const handleNext = () => {
    const nextSong = list.next();
    if (nextSong) setCurrent(nextSong);
  };

  return (
    <div className="screen">
      <h1>Music Player</h1>
      <div className="now-playing">
        <h2>{current.name}</h2>
        <p>{current.artist}</p>
      </div>
      <button onClick={handleNext}>Next</button>
    </div>
  );
}