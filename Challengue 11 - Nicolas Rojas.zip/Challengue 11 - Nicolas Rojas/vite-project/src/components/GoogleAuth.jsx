import { useDispatch } from 'react-redux';
import { signInWithPopup } from 'firebase/auth';
import { auth, googleProvider } from '../firebase/config';
import { login, checkingCredentials, logout } from '../store/slices/authSlice';

export const GoogleAuth = () => {
  const dispatch = useDispatch();

  const handleGoogleSignIn = async () => {
    dispatch(checkingCredentials());
    try {
      const { user } = await signInWithPopup(auth, googleProvider);
      dispatch(login({
        uid: user.uid,
        email: user.email,
        displayName: user.displayName
      }));
    } catch (error) {
      dispatch(logout({ errorMessage: error.message }));
    }
  };

  return (
    <button onClick={handleGoogleSignIn}>
      Sign in with Google
    </button>
  );
};