import { useDispatch } from 'react-redux';
import { auth } from '../firebase/config';
import { signOut } from 'firebase/auth';
import { logout } from '../store/slices/authSlice';

export const LogoutButton = () => {
  const dispatch = useDispatch();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      dispatch(logout());
    } catch (error) {
      dispatch(logout({ errorMessage: error.message }));
    }
  };

  return (
    <button onClick={handleLogout}>
      Logout
    </button>
  );
};