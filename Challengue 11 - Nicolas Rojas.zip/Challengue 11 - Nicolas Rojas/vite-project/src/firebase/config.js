import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';


const firebaseConfig = {
  apiKey: "AIzaSyDF7CXpD0N3x53aBQPOXg6Ui82YnIlV2Ec",
  authDomain: "auth-redux-demo-b0358.firebaseapp.com",
  projectId: "auth-redux-demo-b0358",
  storageBucket: "auth-redux-demo-b0358.firebasestorage.app",
  messagingSenderId: "263942202843",
  appId: "1:263942202843:web:bb2ff8fca3676fefadf3fe"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

export { auth, googleProvider };
