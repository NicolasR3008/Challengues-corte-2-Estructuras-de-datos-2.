import { useSelector } from 'react-redux';
import { LoginForm } from './components/LoginForm';
import { GoogleAuth } from './components/GoogleAuth';
import { LogoutButton } from './components/LogoutButton';

function App() {
  const { status } = useSelector(state => state.auth);

  return (
    <div style={{ padding: '20px' }}>
      {status === 'authenticated' ? (
        <div>
          <h1>Welcome!</h1>
          <LogoutButton />
        </div>
      ) : (
        <div>
          <h2>Login</h2>
          <LoginForm />
          <p>Or</p>
          <GoogleAuth />
        </div>
      )}
    </div>
  );
}

export default App;